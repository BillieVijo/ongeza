<!DOCTYPE html>
<html>
<head>
	<title>Ongeza Project</title>
</head>
<body>
	<h1>ONGEZA Project</h1>
	<ul>
		<li><a href="register.php">Register</a> Custormer</li>
		<li><a href="view.php">View</a> Customaers</li>
	</ul>

</body>
</html>